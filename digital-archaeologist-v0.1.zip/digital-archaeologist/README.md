# Digital Archaeologist

Digital Archaeologist continuously discovers neglected, abandoned, broken, or under-monetised public digital assets and ranks them for human investigation.

## v0.1 safety boundary

The MVP is discovery and research only. It does **not** purchase assets, contact owners, spend money, access private accounts, acquire domains, deploy projects, or automatically fork/publish projects.

## Development

```bash
python -m pip install -e '.[dev]'
pytest -q
```

## MVP validation status

The automated MVP test suite currently exercises discovery, normalisation, deduplication, persistence, deterministic scoring, evidence-backed adversarial investigation, dashboard view logic, scheduled jobs, and the end-to-end pipeline.

The planned live validation is deliberately read-only: collect at least 100 public candidates, manually inspect the top 20, and measure whether 3–5 survive as actionable opportunities. The current execution sandbox has DNS/network restrictions, so the live GitHub/web collector trial must be run on the VPS rather than counted as completed here.
