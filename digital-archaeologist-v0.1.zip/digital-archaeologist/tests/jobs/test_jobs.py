from digital_archaeologist.domain.models import Candidate, OpportunityReport
from digital_archaeologist.jobs.run_discovery import run_discovery_job
from digital_archaeologist.jobs.run_investigation import run_investigation_job
from digital_archaeologist.storage.database import Database
from digital_archaeologist.storage.repositories import Repository


class FakePipeline:
    def __init__(self): self.calls = 0
    def run(self):
        self.calls += 1
        return type("Summary", (), {"discovered": 1, "new": 1, "duplicates": 0, "failed": 0, "scoreable": 1})()


class FakeInvestigator:
    def __init__(self, repo, failing_id=None): self.repo = repo; self.failing_id = failing_id; self.seen = []
    def investigate(self, candidate):
        self.seen.append(candidate.id)
        if candidate.id == self.failing_id: raise RuntimeError("bad candidate")
        report = OpportunityReport(candidate_id=candidate.id, total_score=candidate.score or 0, confidence=0.7, verdict="POSSIBLE", recommendation="Review")
        self.repo.save_report(report)
        return report


def test_repeated_discovery_job_delegates_cleanly_to_idempotent_pipeline():
    pipeline = FakePipeline()
    first = run_discovery_job(pipeline=pipeline)
    second = run_discovery_job(pipeline=pipeline)
    assert first.discovered == second.discovered == 1
    assert pipeline.calls == 2


def test_investigation_only_processes_candidates_above_threshold_and_skips_existing_reports():
    repo = Repository(Database("sqlite+pysqlite:///:memory:"))
    low = Candidate(canonical_identity="low", source="web", url="https://low.test", category="website", score=60)
    high = Candidate(canonical_identity="high", source="web", url="https://high.test", category="website", score=80)
    done = Candidate(canonical_identity="done", source="web", url="https://done.test", category="website", score=95)
    for c in [low, high, done]: repo.upsert_candidate(c)
    repo.save_report(OpportunityReport(candidate_id=done.id, total_score=95, confidence=0.9, verdict="POSSIBLE", recommendation="Done"))
    investigator = FakeInvestigator(repo)
    summary = run_investigation_job(repository=repo, investigator=investigator, limit=10, threshold=75)
    assert summary.investigated == 1
    assert summary.failed == 0
    assert investigator.seen == [high.id]


def test_failed_investigation_does_not_stop_subsequent_candidates():
    repo = Repository(Database("sqlite+pysqlite:///:memory:"))
    a = Candidate(canonical_identity="a", source="web", url="https://a.test", category="website", score=90)
    b = Candidate(canonical_identity="b", source="web", url="https://b.test", category="website", score=89)
    repo.upsert_candidate(a); repo.upsert_candidate(b)
    investigator = FakeInvestigator(repo, failing_id=a.id)
    summary = run_investigation_job(repository=repo, investigator=investigator, limit=10, threshold=75)
    assert summary.failed == 1
    assert summary.investigated == 1
    assert set(investigator.seen) == {a.id, b.id}
