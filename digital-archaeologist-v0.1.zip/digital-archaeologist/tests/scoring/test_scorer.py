from digital_archaeologist.domain.models import Candidate
from digital_archaeologist.scoring.scorer import score_candidate


def test_known_fixture_produces_expected_components_and_total():
    candidate = Candidate(
        canonical_identity="github:owner/repo", source="github", url="https://github.com/owner/repo", category="software",
        metadata={
            "demand_score": 20, "traction_score": 16, "neglect_score": 12,
            "resurrection_score": 11, "monetization_score": 10, "competition_score": 3,
            "license_clarity_score": 4,
        },
    )
    result = score_candidate(candidate)
    assert result.component_scores == {"demand": 20, "existing_traction": 16, "neglect": 12, "ease_of_resurrection": 11, "monetisation": 10, "competition": 3, "licence_ownership": 4}
    assert result.total_score == 76


def test_missing_evidence_uses_neutral_unknown_treatment():
    candidate = Candidate(canonical_identity="web:example.com", source="web", url="https://example.com", category="website")
    result = score_candidate(candidate)
    assert result.total_score == 50
    assert all("unknown" in reason.lower() for reason in result.reasons)


def test_total_is_always_between_zero_and_hundred():
    high = Candidate(canonical_identity="x", source="web", url="https://x.test", category="website", metadata={
        "demand_score": 999, "traction_score": 999, "neglect_score": 999, "resurrection_score": 999,
        "monetization_score": 999, "competition_score": 999, "license_clarity_score": 999,
    })
    low = Candidate(canonical_identity="y", source="web", url="https://y.test", category="website", metadata={
        "demand_score": -999, "traction_score": -999, "neglect_score": -999, "resurrection_score": -999,
        "monetization_score": -999, "competition_score": -999, "license_clarity_score": -999,
    })
    assert 0 <= score_candidate(high).total_score <= 100
    assert 0 <= score_candidate(low).total_score <= 100
