import pytest
from pydantic import ValidationError

from digital_archaeologist.research.validator import ResearchResponse, validate_response


def valid_response():
    return ResearchResponse(
        verdict="POSSIBLE", total_score=71, confidence=0.75,
        component_scores={"demand": 18, "existing_traction": 15, "neglect": 12, "ease_of_resurrection": 11, "monetisation": 10, "competition": 2, "licence_ownership": 3},
        evidence=[{"id": "e1", "claim": "Project has unresolved demand", "evidence_type": "OBSERVED", "source_url": "https://example.com", "summary": "Open requests remain."}],
        risks=["Demand may have shifted"], recommendation="Investigate competitors", adversarial_review="The strongest counterpoint is weak current demand.", next_action="Research competitors",
    )


def test_valid_structured_output_is_accepted():
    result = validate_response(valid_response())
    assert result.verdict == "POSSIBLE"
    assert result.evidence[0].id == "e1"


def test_malformed_json_is_rejected():
    with pytest.raises((ValidationError, ValueError)):
        validate_response("not-json")


def test_claim_without_evidence_reference_is_rejected():
    response = valid_response()
    response.evidence[0].id = ""
    with pytest.raises(ValueError, match="evidence"):
        validate_response(response)


def test_unsupported_verdict_and_score_ranges_are_rejected():
    response = valid_response()
    response.verdict = "BUY IT"
    with pytest.raises(ValueError):
        validate_response(response)
    response = valid_response()
    response.total_score = 101
    with pytest.raises(ValueError):
        validate_response(response)
