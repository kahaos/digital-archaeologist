import pytest

from digital_archaeologist.domain.models import Candidate
from digital_archaeologist.research.investigator import ResearchInvestigator
from digital_archaeologist.research.provider import ResearchResponse
from digital_archaeologist.storage.database import Database
from digital_archaeologist.storage.repositories import Repository


class FakeProvider:
    def __init__(self, responses): self.responses = iter(responses); self.phases = []; self.instructions = []
    def generate(self, request):
        self.phases.append(request.phase); self.instructions.append(request.instructions)
        return next(self.responses)


def response(verdict="POSSIBLE", adversarial="Counterpoint checked"):
    return ResearchResponse(
        verdict=verdict, total_score=72, confidence=0.8,
        component_scores={"demand": 18, "existing_traction": 15, "neglect": 12, "ease_of_resurrection": 11, "monetisation": 10, "competition": 3, "licence_ownership": 3},
        evidence=[{"id": "e1", "claim": "Users still ask for this", "evidence_type": "OBSERVED", "source_url": "https://example.com/issues", "summary": "Recent requests exist."}],
        risks=["Competition"], recommendation="Research the market", adversarial_review=adversarial, next_action="Review competitors",
    )


def test_investigator_builds_report_and_persists_evidence():
    repo = Repository(Database("sqlite+pysqlite:///:memory:"))
    candidate = Candidate(canonical_identity="web:example.com", source="web", url="https://example.com", category="website")
    repo.upsert_candidate(candidate)
    provider = FakeProvider([response(), response()])
    report = ResearchInvestigator(provider, repo).investigate(candidate)
    assert provider.phases == ["initial", "adversarial"]
    assert report.verdict == "POSSIBLE"
    assert report.evidence_ids == ["e1"]
    assert repo.get_report(candidate.id).recommendation == "Research the market"
    assert repo.get_evidence(candidate.id)[0].source_url == "https://example.com/issues"


def test_strong_verdict_requires_adversarial_review():
    repo = Repository(Database("sqlite+pysqlite:///:memory:"))
    candidate = Candidate(canonical_identity="web:example.com", source="web", url="https://example.com", category="website")
    repo.upsert_candidate(candidate)
    provider = FakeProvider([response("STRONG OPPORTUNITY", "Counterpoint checked"), response("STRONG OPPORTUNITY", "")])
    with pytest.raises(ValueError, match="adversarial"):
        ResearchInvestigator(provider, repo).investigate(candidate)
    assert repo.get_report(candidate.id) is None

def test_investigator_sends_distinct_initial_and_adversarial_instructions():
    repo = Repository(Database("sqlite+pysqlite:///:memory:"))
    candidate = Candidate(canonical_identity="web:example.com", source="web", url="https://example.com", category="website")
    repo.upsert_candidate(candidate)
    provider = FakeProvider([response(), response()])
    ResearchInvestigator(provider, repo).investigate(candidate)
    assert provider.phases == ["initial", "adversarial"]
    assert provider.instructions[0] != provider.instructions[1]
    assert "sceptical" in provider.instructions[1].lower()
