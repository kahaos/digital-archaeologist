from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine, make_url
from pathlib import Path
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class Database:
    def __init__(self, url: str = "sqlite:///data/digital_archaeologist.db") -> None:
        connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
        if url.startswith("sqlite") and ":memory:" not in url:
            database_path = make_url(url).database
            if database_path:
                Path(database_path).expanduser().parent.mkdir(parents=True, exist_ok=True)
        self.engine: Engine = create_engine(url, future=True, connect_args=connect_args)
        self._initialise()

    def _initialise(self) -> None:
        from .repositories import CandidateRow, EvidenceRow, ReportRow  # noqa: F401
        Base.metadata.create_all(self.engine)
