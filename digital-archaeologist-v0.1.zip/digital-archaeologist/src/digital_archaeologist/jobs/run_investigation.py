from __future__ import annotations
import logging
import uuid
from pydantic import BaseModel
from digital_archaeologist.config import Settings
from digital_archaeologist.research.investigator import ResearchInvestigator
from digital_archaeologist.storage.database import Database
from digital_archaeologist.storage.repositories import Repository

logger = logging.getLogger(__name__)

class InvestigationRunSummary(BaseModel):
    investigated: int = 0
    failed: int = 0
    skipped: int = 0


def run_investigation_job(*, repository: Repository | None = None, investigator: ResearchInvestigator | None = None, limit: int = 10, threshold: float | None = None) -> InvestigationRunSummary:
    run_id = uuid.uuid4().hex
    settings = Settings()
    threshold = settings.investigation_threshold if threshold is None else threshold
    repository = repository or Repository(Database(settings.database_url))
    if investigator is None:
        raise RuntimeError("an AI research provider must be configured before investigation jobs can run")
    candidates = [c for c in repository.list_candidates() if (c.score or 0) >= threshold]
    summary = InvestigationRunSummary()
    for candidate in candidates[:limit]:
        if repository.get_report(candidate.id) is not None:
            summary.skipped += 1
            continue
        try:
            investigator.investigate(candidate)
            summary.investigated += 1
        except Exception as exc:
            summary.failed += 1
            logger.exception("investigation failed run_id=%s candidate=%s error=%s", run_id, candidate.id, exc)
    return summary


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print((run_discovery_job() if "run_discovery_job" in globals() else run_investigation_job()).model_dump_json())
