from __future__ import annotations

from pydantic import BaseModel, Field

from digital_archaeologist.domain.models import Candidate
from .rules import WEIGHTS, bounded


class OpportunityScore(BaseModel):
    component_scores: dict[str, float] = Field(default_factory=dict)
    total_score: float
    reasons: list[str] = Field(default_factory=list)


def score_candidate(candidate: Candidate) -> OpportunityScore:
    m = candidate.metadata
    mapping = {
        "demand": "demand_score",
        "existing_traction": "traction_score",
        "neglect": "neglect_score",
        "ease_of_resurrection": "resurrection_score",
        "monetisation": "monetization_score",
        "competition": "competition_score",
        "licence_ownership": "license_clarity_score",
    }
    scores: dict[str, float] = {}
    reasons: list[str] = []
    for component, key in mapping.items():
        if key not in m or m.get(key) is None:
            value = WEIGHTS[component] / 2
            reasons.append(f"{component}: unknown evidence, neutral score applied")
        else:
            value = bounded(m.get(key), WEIGHTS[component], WEIGHTS[component] / 2)
            reasons.append(f"{component}: scored from supplied deterministic evidence")
        scores[component] = value
    total = round(sum(scores.values()), 4)
    return OpportunityScore(component_scores=scores, total_score=total, reasons=reasons)
