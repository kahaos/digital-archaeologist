from __future__ import annotations


def initial_research_prompt() -> str:
    return (
        "Investigate demand, abandonment, competition, technical condition, licence/IP indicators, "
        "resurrection effort, and monetisation. Use only supplied evidence and clearly label unknowns. "
        "Return evidence-backed claims."
    )


def adversarial_research_prompt() -> str:
    return (
        "Act as the sceptical reviewer. Challenge demand, ownership/licence clarity, competitor strength, "
        "technical obsolescence, fake traction, operating costs, active ownership, and regulatory risks. "
        "Look for reasons not to pursue the opportunity. Preserve evidence and label unknowns."
    )
