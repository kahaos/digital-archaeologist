from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, field_validator

Verdict = Literal["STRONG OPPORTUNITY", "POSSIBLE", "WEAK", "REJECT"]
EvidenceType = Literal["OBSERVED", "INFERRED", "ESTIMATED", "UNKNOWN"]
WEIGHTS = {"demand": 25, "existing_traction": 20, "neglect": 15, "ease_of_resurrection": 15, "monetisation": 15, "competition": 5, "licence_ownership": 5}


class EvidenceClaim(BaseModel):
    id: str
    claim: str
    evidence_type: EvidenceType
    source_url: str | None = None
    summary: str


class ResearchResponse(BaseModel):
    verdict: Verdict
    total_score: float = Field(ge=0, le=100)
    confidence: float = Field(ge=0, le=1)
    component_scores: dict[str, float]
    evidence: list[EvidenceClaim]
    risks: list[str] = Field(default_factory=list)
    recommendation: str
    adversarial_review: str
    next_action: str


class ValidatedResearch(ResearchResponse):
    pass


def validate_response(response: Any) -> ValidatedResearch:
    if isinstance(response, str):
        response = json.loads(response)
    if hasattr(response, "model_dump"):
        response = response.model_dump()
    validated = ValidatedResearch.model_validate(response)
    if set(validated.component_scores) - set(WEIGHTS):
        raise ValueError("unsupported score component")
    for name, value in validated.component_scores.items():
        if not 0 <= value <= WEIGHTS[name]:
            raise ValueError(f"score for {name} outside allowed range")
    if not validated.evidence:
        raise ValueError("research response requires evidence")
    if any(not item.id.strip() for item in validated.evidence):
        raise ValueError("every claim requires an evidence reference")
    if validated.verdict == "STRONG OPPORTUNITY" and not validated.adversarial_review.strip():
        raise ValueError("strong verdict requires adversarial review")
    return validated
