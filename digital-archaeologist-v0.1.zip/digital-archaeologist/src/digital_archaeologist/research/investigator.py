from __future__ import annotations

from digital_archaeologist.domain.models import Candidate, Evidence, OpportunityReport
from digital_archaeologist.storage.repositories import Repository
from .provider import ResearchProvider, ResearchRequest
from .prompts import adversarial_research_prompt, initial_research_prompt
from .validator import validate_response


class ResearchInvestigator:
    def __init__(self, provider: ResearchProvider, repository: Repository) -> None:
        self.provider = provider
        self.repository = repository

    def investigate(self, candidate: Candidate) -> OpportunityReport:
        evidence = self.repository.get_evidence(candidate.id)
        request = ResearchRequest(candidate=candidate.model_dump(mode="json"), evidence=[item.model_dump(mode="json") for item in evidence], phase="initial", instructions=initial_research_prompt())
        first = validate_response(self.provider.generate(request))
        adversarial = validate_response(self.provider.generate(request.model_copy(update={"phase": "adversarial", "instructions": adversarial_research_prompt()})))
        if first.verdict == "STRONG OPPORTUNITY" and not adversarial.adversarial_review.strip():
            raise ValueError("strong verdict requires adversarial review")
        chosen = adversarial
        persisted_ids: list[str] = []
        for claim in chosen.evidence:
            stored = self.repository.add_evidence(Evidence(candidate_id=candidate.id, claim=claim.claim, evidence_type=claim.evidence_type.lower(), source_url=claim.source_url, summary=claim.summary, id=claim.id))
            persisted_ids.append(stored.id)
        report = OpportunityReport(candidate_id=candidate.id, component_scores=chosen.component_scores, total_score=chosen.total_score, confidence=chosen.confidence, verdict=chosen.verdict, risks=chosen.risks, recommendation=chosen.recommendation, evidence_ids=persisted_ids)
        self.repository.save_report(report)
        return report
