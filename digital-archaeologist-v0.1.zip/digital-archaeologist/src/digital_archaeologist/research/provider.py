from __future__ import annotations

from typing import Any, Protocol

from pydantic import BaseModel, Field


class ResearchRequest(BaseModel):
    candidate: dict[str, Any]
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    phase: str = "initial"
    instructions: str = ""


class ResearchResponse(BaseModel):
    verdict: str
    total_score: float
    confidence: float
    component_scores: dict[str, float] = Field(default_factory=dict)
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    recommendation: str
    adversarial_review: str
    next_action: str


class ResearchProvider(Protocol):
    def generate(self, request: ResearchRequest) -> ResearchResponse: ...
