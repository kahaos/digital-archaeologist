# Digital Archaeologist v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a cheap, autonomous MVP that discovers neglected digital assets, ranks them with deterministic signals, investigates promising candidates with AI, and presents evidence-backed opportunity reports in a simple dashboard.

**Architecture:** Python application with isolated collectors, discovery/normalisation, SQLite persistence, deterministic scoring, AI-assisted research, and a Streamlit dashboard. Scheduled VPS workers run discovery/investigation without granting authority to purchase, contact, deploy, or spend. The interfaces are designed so ForgeOS can govern future execution agents without becoming a v0.1 dependency.

**Tech Stack:** Python 3.12+ compatible code, SQLite, SQLAlchemy, Pydantic, pytest, httpx, BeautifulSoup, GitHub REST API, Streamlit, and a pluggable AI provider interface. Exact dependency versions should be pinned after the first green test run.

**Spec:** `docs/superpowers/specs/2026-10-06-digital-archaeologist-design.md`

## Global Constraints

- Initial discovery sources are GitHub and public websites.
- SQLite is the initial database; do not add PostgreSQL infrastructure in v0.1.
- First-pass scoring is deterministic and totals 100 points.
- AI is used for investigation and synthesis, not as the sole discovery/scoring mechanism.
- Important claims must retain evidence/provenance and distinguish observed, inferred, estimated, and unknown.
- Include an adversarial/sceptical review before a candidate can be classified as a strong opportunity.
- v0.1 must not purchase assets, contact owners, spend money, access private accounts, acquire domains, deploy projects, or automatically publish/fork projects.
- Discovery should run on a low-frequency schedule (once or twice daily initially).
- Dashboard should remain a simple Streamlit application.
- Secrets must stay outside source control.
- Every task follows TDD: failing test, minimal implementation, green verification, commit.

## Review Focus

- Malformed/unreachable external URLs must produce a failed evidence record rather than crash a discovery run — covered by Task 3 web collector tests.
- Duplicate candidates discovered from different URLs/sources must collapse to one canonical candidate without losing provenance — covered by Task 4 deduplication tests.
- Missing GitHub fields, rate limits, and empty repositories must degrade gracefully — covered by Task 3 GitHub collector tests.
- AI output containing unsupported claims, malformed JSON, or missing evidence must be rejected/retried rather than silently persisted — covered by Task 7 research validation tests.
- A scheduled run must be restartable without duplicating candidates or creating overlapping jobs — covered by Task 9 orchestration/idempotency tests.

---

### Task 1: Repository scaffold and configuration

**Files:**
- Create: `pyproject.toml`
- Create: `README.md`
- Create: `.gitignore`
- Create: `.env.example`
- Create: `src/digital_archaeologist/__init__.py`
- Create: `src/digital_archaeologist/config.py`
- Create: `tests/test_config.py`

**Interfaces:**
- Produces `Settings` loaded from environment variables with safe defaults for local development.
- Exposes package metadata/version without importing optional integrations.

- [ ] **Step 1: Write failing configuration tests**
  - Assert defaults include SQLite database URL and disabled external side effects.
  - Assert an environment variable can override the database path.
  - Assert API secrets are never included in `repr(Settings)`.

- [ ] **Step 2: Run targeted tests and verify failure**
  - Run `pytest tests/test_config.py -q`.
  - Expected: import/configuration failures because implementation does not exist.

- [ ] **Step 3: Implement minimal configuration layer**
  - Add typed `Settings` using environment variables.
  - Keep provider-specific secrets optional.
  - Add explicit `DA_DRY_RUN=true` default.

- [ ] **Step 4: Run targeted tests and verify pass**
  - Run `pytest tests/test_config.py -q`.
  - Expected: PASS.

- [ ] **Step 5: Commit**
  - `git add pyproject.toml README.md .gitignore .env.example src tests`
  - `git commit -m "chore: scaffold digital archaeologist"`

### Task 2: Domain models and SQLite persistence

**Files:**
- Create: `src/digital_archaeologist/domain/models.py`
- Create: `src/digital_archaeologist/storage/database.py`
- Create: `src/digital_archaeologist/storage/repositories.py`
- Create: `tests/storage/test_repositories.py`

**Interfaces:**
- `Candidate` stores canonical identity, source, URL, category, metadata, discovery timestamps, and status.
- `Evidence` stores candidate ID, claim, evidence type (`observed|inferred|estimated|unknown`), source URL, excerpt/summary, and collection timestamp.
- `OpportunityReport` stores candidate ID, scores, confidence, verdict, risks, recommendation, and evidence IDs.
- Repository methods: `upsert_candidate()`, `get_candidate()`, `list_candidates()`, `add_evidence()`, `save_report()`, `get_report()`.

- [ ] **Step 1: Write failing persistence tests**
  - Test candidate insert and retrieval.
  - Test candidate upsert is idempotent on canonical identity.
  - Test evidence references an existing candidate.
  - Test report can be stored and retrieved with evidence IDs.

- [ ] **Step 2: Run targeted tests and verify failure**
  - `pytest tests/storage/test_repositories.py -q`.
  - Expected: FAIL because models/repositories are absent.

- [ ] **Step 3: Implement SQLAlchemy/SQLite persistence**
  - Create tables with indexes on canonical URL, source, status, score, and discovered timestamp.
  - Use transactions around individual repository operations.
  - Store flexible collector metadata as JSON.

- [ ] **Step 4: Run tests**
  - `pytest tests/storage/test_repositories.py -q`.
  - Expected: PASS.

- [ ] **Step 5: Commit**
  - `git add src/digital_archaeologist/domain src/digital_archaeologist/storage tests/storage`
  - `git commit -m "feat: add candidate and evidence persistence"`

### Task 3: GitHub and public-web collectors

**Files:**
- Create: `src/digital_archaeologist/collectors/base.py`
- Create: `src/digital_archaeologist/collectors/github.py`
- Create: `src/digital_archaeologist/collectors/web.py`
- Create: `tests/collectors/test_github.py`
- Create: `tests/collectors/test_web.py`

**Interfaces:**
- `Collector.collect() -> list[CandidateDraft]`.
- `GitHubCollector.search(query: str, page: int = 1) -> list[CandidateDraft]`.
- `WebCollector.inspect(url: str) -> CandidateDraft`.
- Collectors return structured drafts; they do not write directly to the database.

- [ ] **Step 1: Write failing GitHub collector tests**
  - Mock the GitHub HTTP response.
  - Assert stars, forks, open issues, last activity, license indicator, and repository URL are mapped into the draft.
  - Assert missing optional fields do not crash parsing.
  - Assert a mocked rate-limit response produces a controlled collector error.

- [ ] **Step 2: Run tests and verify failure**
  - `pytest tests/collectors/test_github.py -q`.

- [ ] **Step 3: Implement GitHub collector**
  - Use `httpx` with timeouts.
  - Support authenticated requests when an optional token is configured, otherwise public API access.
  - Do not commit or expose the token.
  - Keep search queries configurable rather than hard-coded into collector internals.

- [ ] **Step 4: Write failing web collector tests**
  - Mock valid HTML and assert title, status, headings, selected metadata, and URL are extracted.
  - Mock a timeout/HTTP failure and assert a structured failure result.

- [ ] **Step 5: Implement web collector**
  - Use `httpx` and BeautifulSoup.
  - Enforce request timeout and maximum response size.
  - Do not crawl recursively in v0.1.

- [ ] **Step 6: Run collector tests**
  - `pytest tests/collectors -q`.
  - Expected: PASS.

- [ ] **Step 7: Commit**
  - `git add src/digital_archaeologist/collectors tests/collectors`
  - `git commit -m "feat: add github and web collectors"`

### Task 4: Normalisation and deduplication

**Files:**
- Create: `src/digital_archaeologist/discovery/normalizer.py`
- Create: `src/digital_archaeologist/discovery/deduplicator.py`
- Create: `tests/discovery/test_normalizer.py`
- Create: `tests/discovery/test_deduplicator.py`

**Interfaces:**
- `normalize_candidate(draft: CandidateDraft) -> CandidateDraft`.
- `canonical_identity(draft: CandidateDraft) -> str`.
- `deduplicate(drafts: list[CandidateDraft]) -> list[CandidateDraft]`.

- [ ] **Step 1: Write failing normalisation tests**
  - Assert URL scheme/host casing and removable tracking parameters are normalised.
  - Assert GitHub repository URLs map to a stable canonical identity.

- [ ] **Step 2: Implement normalisation**
  - Preserve the original URL as provenance while deriving canonical identity separately.

- [ ] **Step 3: Write failing deduplication tests**
  - Feed equivalent GitHub URLs and assert one candidate remains.
  - Assert provenance/source references from duplicates are retained.

- [ ] **Step 4: Implement deduplication**
  - Merge duplicates deterministically by canonical identity.

- [ ] **Step 5: Run tests**
  - `pytest tests/discovery -q`.

- [ ] **Step 6: Commit**
  - `git add src/digital_archaeologist/discovery tests/discovery`
  - `git commit -m "feat: normalize and deduplicate discoveries"`

### Task 5: Deterministic opportunity scoring

**Files:**
- Create: `src/digital_archaeologist/scoring/rules.py`
- Create: `src/digital_archaeologist/scoring/scorer.py`
- Create: `tests/scoring/test_scorer.py`

**Interfaces:**
- `OpportunityScore` contains component scores, total score, and reasons.
- `score_candidate(candidate: Candidate) -> OpportunityScore`.

**Exact initial weights:**
- Demand: 25
- Existing traction: 20
- Neglect/abandonment: 15
- Ease of resurrection: 15
- Monetisation potential: 15
- Competition: 5
- Licence/ownership clarity: 5
- Total: 100

- [ ] **Step 1: Write failing scoring tests**
  - Assert a known fixture produces the expected component values and total.
  - Assert missing evidence produces neutral/unknown treatment rather than invented positives.
  - Assert total is always between 0 and 100.

- [ ] **Step 2: Implement deterministic rules**
  - Keep rule functions pure and individually testable.
  - Record human-readable reasons alongside numeric components.

- [ ] **Step 3: Run tests**
  - `pytest tests/scoring/test_scorer.py -q`.

- [ ] **Step 4: Commit**
  - `git add src/digital_archaeologist/scoring tests/scoring`
  - `git commit -m "feat: add deterministic opportunity scoring"`

### Task 6: Candidate discovery orchestration

**Files:**
- Create: `src/digital_archaeologist/discovery/pipeline.py`
- Create: `tests/discovery/test_pipeline.py`

**Interfaces:**
- `DiscoveryPipeline.run() -> DiscoveryRunSummary`.
- Pipeline order: collect → normalise → deduplicate → persist → score → persist scores.

- [ ] **Step 1: Write failing pipeline tests**
  - Use fake collectors and an in-memory database.
  - Assert all collector drafts are normalised and deduplicated before persistence.
  - Assert rerunning the same batch does not create duplicate candidates.

- [ ] **Step 2: Implement pipeline**
  - Isolate collector failures so one source cannot abort the entire run.
  - Return counts for discovered, new, duplicate, failed, and scoreable candidates.

- [ ] **Step 3: Run tests**
  - `pytest tests/discovery/test_pipeline.py -q`.

- [ ] **Step 4: Commit**
  - `git add src/digital_archaeologist/discovery/pipeline.py tests/discovery/test_pipeline.py`
  - `git commit -m "feat: add discovery pipeline"`

### Task 7: AI research provider and adversarial investigation

**Files:**
- Create: `src/digital_archaeologist/research/provider.py`
- Create: `src/digital_archaeologist/research/prompts.py`
- Create: `src/digital_archaeologist/research/validator.py`
- Create: `src/digital_archaeologist/research/investigator.py`
- Create: `tests/research/test_validator.py`
- Create: `tests/research/test_investigator.py`

**Interfaces:**
- `ResearchProvider.generate(request: ResearchRequest) -> ResearchResponse`.
- `validate_response(response: ResearchResponse) -> ValidatedResearch`.
- `ResearchInvestigator.investigate(candidate: Candidate) -> OpportunityReport`.

**Required verdicts:** `STRONG OPPORTUNITY`, `POSSIBLE`, `WEAK`, `REJECT`.

**Evidence types:** `OBSERVED`, `INFERRED`, `ESTIMATED`, `UNKNOWN`.

- [ ] **Step 1: Write failing validator tests**
  - Valid structured output is accepted.
  - Malformed JSON is rejected.
  - A claim with no evidence reference is rejected or marked unknown.
  - Unsupported verdict/score ranges are rejected.

- [ ] **Step 2: Implement strict research schema validation**
  - Use Pydantic models.
  - Never persist unvalidated model output.

- [ ] **Step 3: Write failing investigator tests**
  - Mock a provider and assert the investigator builds a report from candidate data plus collected evidence.
  - Assert the adversarial section is required before a strong verdict is accepted.

- [ ] **Step 4: Implement investigator**
  - First pass: demand, abandonment, competition, technical condition, licence/IP indicators, resurrection effort, monetisation.
  - Second pass: sceptical/adversarial review.
  - Preserve source URLs and evidence references.
  - Keep provider behind an interface so OpenAI/other providers can be swapped later.

- [ ] **Step 5: Run research tests**
  - `pytest tests/research -q`.

- [ ] **Step 6: Commit**
  - `git add src/digital_archaeologist/research tests/research`
  - `git commit -m "feat: add evidence-backed AI investigation"`

### Task 8: Streamlit dashboard and opportunity cards

**Files:**
- Create: `src/digital_archaeologist/dashboard/app.py`
- Create: `src/digital_archaeologist/dashboard/views.py`
- Create: `tests/dashboard/test_views.py`

**Interfaces:**
- Dashboard reads through repositories/services only; it must not contain collection or scoring logic.
- Candidate detail view renders score, confidence, verdict, evidence, risks, recommendation, and next action.

- [ ] **Step 1: Write failing view tests**
  - Assert a candidate card contains score, verdict, confidence, and recommendation.
  - Assert evidence type is displayed distinctly.
  - Assert empty database renders a useful empty state.

- [ ] **Step 2: Implement dashboard views**
  - Main metrics: candidates discovered, investigated, strong opportunities, needs review, rejected.
  - Add filters for score, category, source, effort, monetisation, confidence, status, and discovery date.

- [ ] **Step 3: Implement Streamlit app entry point**
  - Keep UI composition separate from data access.

- [ ] **Step 4: Run tests and smoke test**
  - `pytest tests/dashboard/test_views.py -q`.
  - Start locally with `streamlit run src/digital_archaeologist/dashboard/app.py` and confirm the dashboard loads.

- [ ] **Step 5: Commit**
  - `git add src/digital_archaeologist/dashboard tests/dashboard`
  - `git commit -m "feat: add opportunity dashboard"`

### Task 9: Scheduled runs, idempotency, and VPS operations

**Files:**
- Create: `src/digital_archaeologist/jobs/run_discovery.py`
- Create: `src/digital_archaeologist/jobs/run_investigation.py`
- Create: `ops/systemd/digital-archaeologist-discovery.service`
- Create: `ops/systemd/digital-archaeologist-discovery.timer`
- Create: `ops/systemd/digital-archaeologist-dashboard.service`
- Create: `tests/jobs/test_jobs.py`
- Create: `docs/operations.md`

**Interfaces:**
- `run_discovery_job() -> DiscoveryRunSummary`.
- `run_investigation_job(limit: int = 10) -> InvestigationRunSummary`.

- [ ] **Step 1: Write failing job tests**
  - Assert repeated discovery runs are idempotent.
  - Assert investigation only processes candidates above the configured threshold and not already investigated unless explicitly requested.
  - Assert a failed candidate investigation does not prevent subsequent candidates from being processed.

- [ ] **Step 2: Implement jobs**
  - Add structured logging.
  - Add run IDs.
  - Ensure no external side-effect action is reachable from these jobs.

- [ ] **Step 3: Add systemd units**
  - Configure discovery once/twice daily initially.
  - Configure dashboard as a separate service.
  - Load environment from a protected environment file outside Git.

- [ ] **Step 4: Run tests**
  - `pytest tests/jobs/test_jobs.py -q`.

- [ ] **Step 5: Commit**
  - `git add src/digital_archaeologist/jobs ops/systemd tests/jobs docs/operations.md`
  - `git commit -m "ops: add scheduled discovery and investigation jobs"`

### Task 10: End-to-end MVP validation

**Files:**
- Create: `tests/e2e/test_mvp_pipeline.py`
- Modify: `README.md`
- Modify: `docs/operations.md`

**Interfaces:**
- End-to-end fixture exercises collector → normalisation → persistence → scoring → mocked AI investigation → report.

- [ ] **Step 1: Write failing end-to-end test**
  - Provide deterministic fake GitHub/web inputs.
  - Assert at least one candidate reaches a persisted opportunity report.
  - Assert evidence remains attached to the report.

- [ ] **Step 2: Implement/fix integration gaps**
  - Only make changes required to satisfy the end-to-end contract; do not add new features.

- [ ] **Step 3: Run full test suite**
  - `pytest -q`.
  - Expected: all tests pass.

- [ ] **Step 4: Run a real, read-only discovery trial**
  - Execute collectors against public GitHub/web sources with no write-side effects.
  - Target at least 100 candidate records over the validation period.

- [ ] **Step 5: Review the top 20 manually**
  - Record how many are genuinely interesting and how many survive adversarial review.
  - Target: 3–5 actionable opportunities.

- [ ] **Step 6: Commit validation documentation**
  - `git add README.md docs`
  - `git commit -m "docs: record digital archaeologist mvp validation"`

## Final Verification

- `pytest -q`
- Run a read-only discovery cycle against public sources.
- Confirm no secrets appear in Git history or logs.
- Confirm no purchase/contact/deployment capability exists in v0.1.
- Confirm dashboard can render candidates and opportunity reports from SQLite.
- Confirm a failed external source does not stop the complete discovery cycle.
- Confirm duplicate discovery is idempotent.

## Handoff

After the plan is approved, execute task-by-task in an isolated worktree/branch. For this project, **native execution is recommended** because the tasks are sequential and share interfaces heavily; one implementer can maintain consistency more cheaply than repeatedly handing a small codebase to fresh agents. Run the full verification suite before claiming completion.
